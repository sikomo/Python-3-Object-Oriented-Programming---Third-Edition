class UsefulClass:
    """This class might be useful to other modules."""

    pass


def main():
    """Creates a useful class and does something with it for our module."""
    useful = UsefulClass()
    print(useful)


if __name__ == "__main__":
    main()

