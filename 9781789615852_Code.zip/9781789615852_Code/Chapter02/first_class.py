class MyFirstClass: 
    pass 